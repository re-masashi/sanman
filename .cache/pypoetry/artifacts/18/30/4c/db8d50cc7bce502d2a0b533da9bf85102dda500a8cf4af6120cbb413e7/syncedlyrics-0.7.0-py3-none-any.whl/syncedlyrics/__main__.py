from syncedlyrics.cli import cli_handler

if __name__ == "__main__":
    cli_handler()
